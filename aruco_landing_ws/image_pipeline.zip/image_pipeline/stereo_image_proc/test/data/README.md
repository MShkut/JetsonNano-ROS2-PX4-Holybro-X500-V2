The images in this directory were copied from the OpenCV project [from this location](https://github.com/opencv/opencv_extra/tree/dc0c6c1ee2cd142f936e7f957bbc595df2ce17e8/testdata/gpu/stereobm).
Images are licensed under the open-source BSD license: https://opencv.org/license/
