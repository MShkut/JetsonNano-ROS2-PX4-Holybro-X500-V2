# tracetools_image_pipeline

LTTng tracing provider wrapper for image_pipeline ROS 2 meta-package. `tracetools_image_pipeline` is a fork of [tracetools](https://gitlab.com/ros-tracing/ros2_tracing/-/tree/master/tracetools), refer to this package for the original work.

### Quality Declaration

No quality is claimed according to [REP-2004](https://www.ros.org/reps/rep-2004.html).
